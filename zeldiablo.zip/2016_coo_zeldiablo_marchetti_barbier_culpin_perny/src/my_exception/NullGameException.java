package my_exception;

public class NullGameException extends NullPointerException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NullGameException(){
		super("impossible de creer l'object le jeu est n'existe pas ou est null");
	}
	
	public NullGameException(String msg){super(msg);}

}
