/**
 * classe permettant de creer la map du jeu
 * @author Culpin.a
 */

package map;

import gameplay.Character;

import java.util.ArrayList;

public class Map {

	// attributs

	/**
	 * attribut tail_map cette attribut repr�sente les �lement de la map en
	 * fonction des valeur contenue dans le tableau diff�rent seront charger
	 */
	private int[] tile_map;
	
	/**
	 * dimensions de la map
	 */
	private int width, height;

	/**
	 * attributs repr�sentant les mur present dans la map
	 */
	private ArrayList<Wall> walls;

	// constructeur

	/**
	 * constructeur vide ce constructeur creer une map vide
	 *
	 */

	public Map() {

		this.walls = new ArrayList<Wall>(0);
	}

	// methode

	/**
	 * methode loadMap cette methode permet de creer une map
	 * 
	 * @param map
	 *            RandomFloor que permet de creer un mur pour chaque 0
	 *            compris dans ce tableau
	 */

	public void loadMap(RandomFloor map) {
		for (int y = 0 ; y < map.getHeight() ; y++)
		{
			for (int x = 0 ; x < map.getWidth() ; x++)
			{
				if (map.getTile(x, y) == 0)
					walls.add(new Wall(x * 32, y * 32));
			}
		}
		
		width = map.getWidth();
		height = map.getHeight();
		tile_map = map.getTiles();
	}
	
	public void refreshMap(RandomFloor map)
	{
		walls.clear();
		loadMap(map);
	}

	/**
	 * methode getWalls cette methode renvoie l'attribut walls
	 * 
	 * @return renvoie l'attribut walls
	 */
	public ArrayList<Wall> getWalls() {
		return this.walls;
	}
	
	public boolean emptyPlace(int x,int y)
	{
		x = (int)(Math.floor((float)x / 32.0f));
		y = (int)(Math.floor((float)y / 32.0f));
		
		return (tile_map[x + y * width] != 0);
	}

	public boolean emptyPlaceWall(int x,int y)
	{
		for (Wall i : walls)
		{
			if (x < i.getX() + Wall.SIZE && x + Character.SIZE > i.getX() && y < i.getY() + Wall.SIZE && y + Character.SIZE > i.getY())
				return false;
		}
		
		return true;
	}
	
	public void deleteSpecificWall(int x, int y)
	{
		for (Wall i : walls)
		{
			if (x < i.getX() + Wall.SIZE && x + Character.SIZE > i.getX() && y < i.getY() + Wall.SIZE && y + Character.SIZE > i.getY())
			{
				walls.remove(i);
				break;
			}
		}
	}
	
	public int getWidth() {return width;}
	public int getHeight() {return height;}
	public int[] getTile_Map(){return tile_map;}
	
	public boolean equals(Map m)
	{
		boolean res = true;
		for (int i = 0; i <= tile_map.length;i++){
			if(this.tile_map[i] != m.getTile_Map()[i]){
				res=false;
			}
		}
		if(this.width != m.getWidth() || this.height != m.getHeight()){
			res = false;
		}
		return res;
	}
}
