package map;

import java.awt.Point;
import java.util.ArrayList;

public class RandomFloor
{
		private static final int MAX_FEATURES = 1000;
	
		private int width;
		private int height;
		
		/**
		 * 0 = mur
		 * 2 = salle
		 * 3 = couloir
		 */
		private int[] tiles;
		
		private ArrayList<Rect> rooms;
		private int maxRoomSize;
		private int minRoomSize;
		
		private int maxCorSize;
		private int minCorSize;
		
		private ArrayList<Rect> positions;
		
		private class Rect
		{
			public int x, y, width, height;
			
			public Rect(int px, int py, int pw, int ph)
			{
				x = px;
				y = py;
				width = pw;
				height = ph;
			}
		}
		
		private int uniform(int t1, int t2)
		{
			int lower, upper;
			
			if (t1 <= t2)
			{
				lower = t1;
				upper = t2;
			}
			else
			{
				lower = t2;
				upper = t1;
			}
			
			return (int)(Math.random() * (upper - lower)) + lower;
		}
		
		private boolean createFeature()
		{
			for (int i = 0 ; i < MAX_FEATURES ; ++i)
			{
				if (positions.size() == 0)
					break;
					
				int id = uniform(0, positions.size());
				int x, y;
				
				if (positions.get(id).width == 1 && positions.get(id).height == 1)
				{
					x = positions.get(id).x;
					y = positions.get(id).y;
				}
				else if (positions.get(id).width == 1)
				{
					x = positions.get(id).x;
					y = uniform(positions.get(id).y, positions.get(id).y + positions.get(id).height);
				}
				else if (positions.get(id).height == 1)
				{
					x = uniform(positions.get(id).x, positions.get(id).x + positions.get(id).width);
					y = positions.get(id).y;
				}
				else return false;
				
				for (int j = 0 ; j < 4 ; ++j)
				{
					if (placeFeature(x, y, j))
					{
						positions.remove(id);
						
						return true;
					}
				}
			}
			
			return false;
		}
		
		private boolean placeFeature(int x, int y, int d)
		{
			int dx = 0;
			int dy = 0;
	 
			if (d == 0)
				dy = 1;
			else if (d == 1)
				dy = -1;
			else if (d == 2)
				dx = -1;
			else if (d == 3)
				dx = 1;
	 
			if (getTile(x + dx, y + dy) != 2 && getTile(x + dx, y + dy) != 3)
				return false;
				
			int chance = (int)(Math.round(Math.random()));
			
			if (chance == 0) // room
			{
				if (digRoom(x, y, d, false))
					return true;
			}
			else // corridor
			{
				if (digCorridor(x, y, d))
					return true;
			}
			
			return false;
		}
		
		private boolean digRoom(int x, int y, int d, boolean first)
		{
			int dx, dy;
			
			int fx = x;
			int fy = y;
			int fw = uniform(minRoomSize, maxRoomSize + 1);
			int fh = uniform(minRoomSize, maxRoomSize + 1);
			
			switch (d)
			{
				case 0: // up
					dx = 0;
					dy = 1;
					
					fx += fw / 2;
					fw *= -1;
					fh *= -1;
					break;
					
				case 1: // down
					dx = 0;
					dy = -1;
					
					fx -= fw / 2;
					break;
					
				case 2: // right
					dx = -1;
					dy = 0;
					
					fy += fh / 2;
					fh *= -1;
					break;
					
				case 3: // left
					dx = 1;
					dy = 0;
					
					fy -= fh / 2;
					fw *= -1;
					break;
				
				default: return false;
			}
			
			if (getTile(x + dx, y + dy) == 2) // cannot dig a room onto another room
				return false;
				
			if (fw < 0)
			{
				fx += (fw + 1);
				fw *= -1;
			}
			if (fh < 0)
			{
				fy += (fh + 1);
				fh *= -1;
			}
			
			if (fx <= 0 || fx + fw >= width || fy <= 0 || fy + fh >= height)
				return false;
			
			Rect room = new Rect(fx, fy, fw, fh);
			
			if (placeRect(room, 2))
			{
				rooms.add(room);
				
				if (d != 0 || first)
					positions.add(new Rect(fx, fy + fh, fw, 1));
				if (d != 1 || first)
					positions.add(new Rect(fx, fy - 1, fw, 1));
				if (d != 2 || first)
					positions.add(new Rect(fx + fw, fy, 1, fh));
				if (d != 3 || first)
					positions.add(new Rect(fx - 1, fy, 1, fh));
				
				return true;
			}
			
			return false;
		}
		
		private boolean digCorridor(int x, int y, int d)
		{
			int fx = x;
			int fy = y;
			int fw = 1;
			int fh = 1;
			
			switch (d)
			{
				case 0: // up
					fh = -1 * uniform(minCorSize, maxCorSize + 1);
					
					if (getTile(x + 1, y) == 2 || getTile(x + 1, y) == 3 || getTile(x - 1, y) == 2 || getTile(x - 1, y) == 3 || getTile(x + fw + 1, y + fh) == 2 || getTile(x + fw + 1, y + fh) == 3 || getTile(x + fw - 1, y + fh) == 2 || getTile(x + fw - 1, y + fh) == 3)
						return false;
						
					break;
					
				case 1: // down
					fh = uniform(minCorSize, maxCorSize + 1);
					
					if (getTile(x + 1, y) == 2 || getTile(x + 1, y) == 3 || getTile(x - 1, y) == 2 || getTile(x - 1, y) == 3 || getTile(x + fw + 1, y + fh) == 2 || getTile(x + fw + 1, y + fh) == 3 || getTile(x + fw - 1, y + fh) == 2 || getTile(x + fw - 1, y + fh) == 3)
						return false;
						
					break;
					
				case 2: // right
					fw = uniform(minCorSize, maxCorSize + 1);
					
					if (getTile(x, y + 1) == 2 || getTile(x, y + 1) == 3 || getTile(x, y - 1) == 2 || getTile(x, y - 1) == 3 || getTile(x + fw, y + fh + 1) == 2 || getTile(x + fw, y + fh + 1) == 3 || getTile(x + fw, y + fh - 1) == 2 || getTile(x + fw, y + fh - 1) == 3)
						return false;
						
					break;
					
				case 3: // left
					fw = -1 * uniform(minCorSize, maxCorSize + 1);
					
					if (getTile(x, y + 1) == 2 || getTile(x, y + 1) == 3 || getTile(x, y - 1) == 2 || getTile(x, y - 1) == 3 || getTile(x + fw, y + fh + 1) == 2 || getTile(x + fw, y + fh + 1) == 3 || getTile(x + fw, y + fh - 1) == 2 || getTile(x + fw, y + fh - 1) == 3)
						return false;
						
					break;
					
				default: break;
			}
				
			if (fw < 0)
			{
				fx += fw + 1;
				fw *= -1;
			}
			if (fh < 0)
			{
				fy += fh + 1;
				fh *= -1;
			}
			
			if (fx <= 0 || fx + fw >= width || fy <= 0 || fy + fh >= height)
				return false;
			
			Rect cor = new Rect(fx, fy, fw, fh);
			
			if (placeRect(cor, 3))
			{
				switch (d)
				{
					case 0: // up
						positions.add(new Rect(fx, fy - 1, 1, 1));
						break;
						
					case 1: // down
						positions.add(new Rect(fx, fy + fh, 1, 1));
						break;
						
					case 2: // right
						positions.add(new Rect(fx + fw, fy, 1, 1));
						break;
						
					case 3: // left
						positions.add(new Rect(fx - 1, fy, 1, 1));
						break;
						
					default: break;
				}
				
				return true;
			}
			
			return false;
		}
		
		private boolean placeRect(Rect rect, int tile)
		{
			for (int y = rect.y ; y < rect.y + rect.height ; ++y)
			{
				for (int x = rect.x ; x < rect.x + rect.width ; ++x)
				{
					if (getTile(x, y) == 2)
						return false;
						
					if (getTile(x, y) == 3 && tile == 2)
						return false;
				}
			}
			
			for (int y = rect.y ; y < rect.y + rect.height ; ++y)
			{
				for (int x = rect.x ; x < rect.x + rect.width ; ++x)
				{
					setTile(x, y, tile);
				}
			}
			
			return true;
		}
		
		private void setTile(int x, int y, int t)
		{
			tiles[x + (y * width)] = t;
		}
		
		public RandomFloor(int w, int h, int mins, int maxs, int minc, int maxc)
		{
			width = w;
			height = h;
			
			if (maxs > mins)
			{
				maxRoomSize = maxs;
				minRoomSize = mins;
			}
			
			if (maxc > minc)
			{
				
				maxCorSize = maxc;
				minCorSize = minc;
			}
			
			tiles = new int[w * h];
			
			for (int i = 0 ; i < tiles.length ; i++)
				tiles[i] = 0;
			
			rooms = new ArrayList<Rect>(0);
			positions = new ArrayList<Rect>(0);
		}
		
		public void generate(int maxFeatures)
		{
			if (!digRoom(width / 2, height / 2, uniform(0, 4), true))
			{
				System.out.println("Cannot dig out first room.");
				return;
			}
			
			for (int i = 1 ; i < maxFeatures ; ++i)
			{
				if (!createFeature())
				{
					System.out.println("Unable to place more features. => placed " + i + " features.");
					break;
				}
			}
		}
		
		public int getTile(int x, int y)
		{
			if (x < 0 || y < 0 || x >= width || y >= height)
				return 0;
			
			return tiles[x + (y * width)];
		}
		
		public int[] getTiles() {return tiles;}
		public int getWidth() {return width;}
		public int getHeight() {return height;}
		
		public Point getRoom()
		{
			int id = uniform(0, rooms.size());
			int x = uniform(rooms.get(id).x, rooms.get(id).x + rooms.get(id).width);
			int y = uniform(rooms.get(id).y, rooms.get(id).y + rooms.get(id).height);
			
			Point p = new Point(x * 32, y * 32);
			
			return p;
		}
}