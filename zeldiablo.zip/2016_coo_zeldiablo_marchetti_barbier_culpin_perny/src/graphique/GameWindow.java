package graphique;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

import app.Game;
import gameplay.Character;
import gameplay.Item;
import gameplay.PlayerController;
import map.Wall;

public class GameWindow extends JPanel {

	private static final long serialVersionUID = -272386725940545498L;

	private Game game;
	private BufferedImage wallImg, groundImg, charImg, enemyImg, charFr, enemyFr, gameOverImg, winImg;

	private int frame;
	private boolean win;
	int it;

	public GameWindow(Game g) {
		win = false;
		frame = 0;
		it = 0;

		game = g;
		addKeyListener(new PlayerController(g.getPlayer()));

		try {
			wallImg = ImageIO.read(new File("sprites/wall.png"));
			groundImg = ImageIO.read(new File("sprites/ground.png"));
			charImg = ImageIO.read(new File("sprites/perso.png"));
			charFr = charImg.getSubimage(0, 0, 16, 16);
			enemyImg = ImageIO.read(new File("sprites/mechant.png"));
			enemyFr = enemyImg.getSubimage(0, 0, 16, 16);
			gameOverImg = ImageIO.read(new File("sprites/gameOver.png"));
			winImg = ImageIO.read(new File("sprites/win.png"));

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * affiche
	 */
	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		for (int y = 0; y < game.getMap().getHeight() * 32; y += 32) {
			for (int x = 0; x < game.getMap().getWidth() * 32; x += 32)
				g.drawImage(groundImg, x, y, null);
		}

		for (Wall w : this.game.getMap().getWalls()) {
			g.drawImage(wallImg, w.getX(), w.getY(), null);
		}

		double locationX = charFr.getWidth() / 2;
		double locationY = charFr.getHeight() / 2;
		AffineTransform tx = AffineTransform.getRotateInstance(Math.toRadians(game.getPlayer().getDirection()),
				locationX, locationY);
		AffineTransformOp op = new AffineTransformOp(tx, AffineTransformOp.TYPE_BILINEAR);
		g.drawImage(op.filter(charFr, null), game.getPlayer().getX(), game.getPlayer().getY(), null);

		for (Character i : game.getCharacters()) {
			tx = AffineTransform.getRotateInstance(Math.toRadians(i.getDirection()), locationX, locationY);
			op = new AffineTransformOp(tx, AffineTransformOp.TYPE_BILINEAR);
			g.drawImage((op.filter(enemyFr, null)), i.getX(), i.getY(), null);
		}

		for (Item i : game.getItems())
			i.display(g);

		if (!game.getGoal().find(game.getPlayer().getX(), game.getPlayer().getY())) {
			game.getGoal().display(g);

			if (!game.getPlayer().getAlive()) {
				g.drawImage(gameOverImg, -128, -32, null);

			}
			if (win) {
				g.drawImage(winImg, -128, -32, null);
			}
		}
		
		g.setFont(new Font("Arial", 24, 24));
		g.drawString("Score : " + game.getScore() + "        �tage : " + game.getNbroom(), 16, 24);
	}

	/**
	 * methode update cette methode sert a mettre a jour l'affichager afin
	 * d'animer les sprite
	 * 
	 */
	public void update() {
		it++;
		frame = (int) (it % 12);

		charFr = charImg.getSubimage(frame * 16, 0, 16, 16);
		enemyFr = enemyImg.getSubimage(frame * 16, 0, 16, 16);
	}
	
	public void setWin(boolean s) {win = s;}
}