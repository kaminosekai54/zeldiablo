package gameplay;

import app.Game;
import my_exception.NullGameException;

/**
 * @author marchett9u aka EnderAsh
 * 
 * Cette classe g�re les personnages en g�n�ral (joueur, pnj, etc...)
 */
public abstract class Character
{
	public final static int SIZE = 16;
	
	protected int direction, speed, speedMax, x, y;
	
	protected Game game;
	
	/**
	 * @param a position x initialle
	 * @param b position y initialle
	 * @param sm vitesse maximale
	 */
	public Character(int a, int b, int sm, Game g) throws NullGameException
	{
		if (a<0)
			a=0;
		if (b<0)
			b=0;
		if (sm<=0)
			sm=1;
		
		this.x=a;
		this.y=b;
		this.speedMax=sm;
		this.direction=0;
		this.speed=0;
		if (g!=null)
		game = g;
		else
			throw new NullGameException("impossible de creer le personnage, le jeu est null ou n'existe pas");
	}
	
	/**
	 * Met � jour les coordonn�es en fonction de la vitesse et de la direction
	 */
	public void update()
	{
		int newX, newY;
		
		newX = (int)(Math.cos(Math.toRadians(direction)) * speed);
		newY = (int)(Math.sin(Math.toRadians(direction)) * speed);
		
		if (game.getPlayer().hasPickaxe() && this instanceof Player)
		{
			game.getMap().deleteSpecificWall(x + newX, y + newY);
		}
		
		if (game.getMap().emptyPlaceWall(x + newX, y))
		{
			x += newX;
		}
		if (game.getMap().emptyPlaceWall(x, y + newY))
		{
			y += newY;
		}
		
		if (x < 0) x = 0;
		if (y < 0) y = 0;
	}
	
	/**
	 * G�re le personnage en fonction de ses propres attributs
	 */
	public abstract void manage();
	
	public int getX() {return this.x;}
	public int getY() {return this.y;}
	public int getSpeed() {return speed;}
	public int getSpeedMax(){return speedMax;}
	public int getDirection() {return direction;}
	public void setCoords(int px, int py) {x = px; y = py;}
}
