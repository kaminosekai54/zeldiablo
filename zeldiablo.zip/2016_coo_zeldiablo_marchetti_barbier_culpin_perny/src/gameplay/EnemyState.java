package gameplay;

public enum EnemyState 
{
	STOP,
	CHASE
}
