package gameplay;

public enum Dir
{
	EAST(0),
	NORTH(270),
	WEST(180),
	SOUTH(90);
	
	private int value;
	
	Dir(int v) {value = v;}
	int toInt() {return value;}
}