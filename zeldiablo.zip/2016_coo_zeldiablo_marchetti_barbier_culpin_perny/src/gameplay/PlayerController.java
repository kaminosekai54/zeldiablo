/**
 *  classe permettant de gerrer les actions au clavier de l'utilisateur
 *  @author Culpin.a
 */

package gameplay;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import graphique.GameWindow;

public class PlayerController implements KeyListener {

	// attributs

	/**
	 * attribut de type player il permet d'effectuer les action de mouvement sur
	 * le joueur
	 */
	private Player player;

	// constructeur

	/**
	 * constructeur permettant de construire un controler
	 * 
	 * @param p
	 *            correspond au player sur lesquelles les action seront
	 *            effectuer
	 */

	public PlayerController(Player p) {
		if (p != null)
			this.player = p;

	}

	@Override
	public void keyPressed(KeyEvent e) {

		GameWindow gw = (GameWindow) (e.getSource());

		switch (e.getKeyCode()) {

		case KeyEvent.VK_UP:
			player.executeAction(PlayerAction.MOVEUP);
			break;

		case KeyEvent.VK_LEFT:
			player.executeAction(PlayerAction.MOVELEFT);
			break;
		case KeyEvent.VK_RIGHT:
			player.executeAction(PlayerAction.MOVERIGHT);
			break;
		case KeyEvent.VK_DOWN:
			player.executeAction(PlayerAction.MOVEDOWN);
			break;
		

		}
		gw.repaint();

	}

	@Override
	public void keyReleased(KeyEvent e) {


		if
		(
				(e.getKeyCode() == KeyEvent.VK_UP && player.getAction() == PlayerAction.MOVEUP)
				|| (e.getKeyCode() == KeyEvent.VK_LEFT && player.getAction() == PlayerAction.MOVELEFT)
				|| (e.getKeyCode() == KeyEvent.VK_RIGHT && player.getAction() == PlayerAction.MOVERIGHT)
				|| (e.getKeyCode() == KeyEvent.VK_DOWN && player.getAction() == PlayerAction.MOVEDOWN)
		)
		{
			player.executeAction(PlayerAction.STOP);
		}

	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

}
