package gameplay;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Stairs extends Goal{
	
	private BufferedImage stairsImg;

	public Stairs(int a, int b)
	{
		super(a, b);
		try {
			stairsImg = ImageIO.read(new File("sprites/ladder.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void display(Graphics g){
		
		
		g.drawImage(this.stairsImg, this.x, this.y, null);
		
	}
	
}
