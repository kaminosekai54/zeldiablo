package gameplay;

import map.Wall;
import my_exception.NullGameException;
import app.Game;

public class Enemy extends Character
{
	private int aggroRange;
	private boolean panic;
	private int it;
	private EnemyState state;
	
	private class Vector
	{
		public double x;
		public double y;
		
		/**
		 * Creation de Vector
		 * @param px
		 * @param py
		 */
		public Vector(double px, double py)
		{
			x = px;
			y = py;
		}
		
		public double norm()
		{
			return (Math.sqrt(x*x + y*y));
		}
		
		public double arg()
		{
			double res = Math.atan2(y, x);
			
			return res;
		}
		
		public Vector add(Vector v)
		{
			return new Vector(x + v.x, y + v.y);
		}
		
		public Vector multiplyByReal(double real)
		{
			return new Vector(this.x * real, this.y * real);
		}
		
		public Vector normalize()
		{
			return this.multiplyByReal(1 / this.norm());
		}
	}
	
	/**
	 * @param a position x initialle
	 * @param b position y initialle
	 * @param sm vitesse maximale
	 * @throws NullGameException 
	 */
	public Enemy(int a, int b, int sm, Game g) throws NullGameException
	{
		super(a, b, sm, g);
		this.aggroRange=128;
		this.state=EnemyState.STOP;
		panic = false;
		it = 0;
	}
	
	/**
	 * modifie attitude de l'ennemi
	 * @param es
	 */
	public void changeState(EnemyState es)
	{
		this.state=es;
	}
	
	public void manage()
	{
		if (panic)
		{
			if (it > 0)
				it --;
			else
				panic = false;
		}
		
		int distance = (game.getPlayer().getY() - y)*(game.getPlayer().getY() - y) + (game.getPlayer().getX() - x)*(game.getPlayer().getX() - x);
		
		if(distance <= aggroRange * aggroRange)
		{
			this.changeState(EnemyState.CHASE);
			aggroRange = this.aggroRange*2;
		}
		else
		{
			this.changeState(EnemyState.STOP);
			aggroRange = 128;
		}
		
		if(this.state==EnemyState.STOP)
		{
			if (speed > 0 ) speed--;
		}
		else if(this.state==EnemyState.CHASE)
		{
			double angle = Math.toDegrees(Math.atan2(game.getPlayer().getY() - y, game.getPlayer().getX() - x));
		    if (angle < 0) angle += 360;
		    
		    Vector velocity = new Vector(Math.cos(Math.toRadians(angle)) * speedMax, Math.sin(Math.toRadians(angle)) * speedMax);
		    Vector steering = new Vector(0, 0);
		    
		    // collision avoidance
		    
		    Vector ahead = new Vector(x, y).add(velocity.normalize().multiplyByReal(64));
		    
		    double actual_d = 999999999;
		    Vector obstaclePos = null;
		    
		    for (Wall i : game.getMap().getWalls())
		    {
		    	double d = Math.sqrt((x - i.getX())*(x - i.getX()) + (y - i.getY())*(y - i.getY()));
		    	
		    	if (d < actual_d)
		    	{
		    		actual_d = d;
		    		obstaclePos = new Vector(i.getX() + 24, i.getY() + 24);
		    	}
		    }
		    
		    Vector avoidance = null;
		    
		    if (obstaclePos != null)
		    {
		    	avoidance = ahead.add(obstaclePos.multiplyByReal(-1));
		    	avoidance = (avoidance.normalize()).multiplyByReal(128);
		    }
		    
		    // queue
		    
		    Vector qa = velocity.normalize().multiplyByReal(64);
		    ahead = qa.add(new Vector(x, y));
		    
		    Character neighbor = null;
		    
		    for (Character i : game.getCharacters())
		    {
		    	double d = Math.sqrt((ahead.x - i.getX())*(ahead.x - i.getX()) + (ahead.y - i.getY())*(ahead.y - i.getY()));
		    	
		    	if (i != this && d <= 64)
		    	{
		    		neighbor = i;
		    		break;
		    	}
		    }
		    
		    Vector brake = null;
		    
		    if (neighbor != null)
		    {
		    	brake = new Vector(-steering.x * 0.8, -steering.y * 0.8);
		    	brake.add(velocity.multiplyByReal(-1));
		    	
		    	if (Math.sqrt((x - neighbor.x) * (x - neighbor.x) + (y - neighbor.y) * (y - neighbor.y)) <= 64)
		    		velocity.multiplyByReal(0.3);
		    }
		    
		    if (avoidance != null) steering.add(avoidance);
		    if (brake != null) steering.add(brake);
		    
		    Vector fin = velocity.add(steering);
		    
		    if (panic) fin = fin.multiplyByReal(-1);
		    
		    direction = (int)(Math.toDegrees(fin.arg()));
		    if (direction < 0) direction += 360;
		    
		    speed = (int)fin.norm();
		}
		
		this.update();
	}
	
	public void panic()
	{
		panic = true;
		it = 200;
	}
	
	public EnemyState getState(){
		return this.state;
	}
	
	public boolean getPanic(){
		return this.panic;
	}
}