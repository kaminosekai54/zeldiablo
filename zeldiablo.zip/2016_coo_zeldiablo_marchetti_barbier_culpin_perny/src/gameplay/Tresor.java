package gameplay;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Tresor extends Goal{
	
	private BufferedImage tresorImg;
	
	public Tresor(int a, int b)
	{
		super(a, b);
		try {
			tresorImg = ImageIO.read(new File("sprites/tresor.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void display(Graphics g){
		g.drawImage(this.tresorImg, this.x, this.y, null);
		
	}
	
}
