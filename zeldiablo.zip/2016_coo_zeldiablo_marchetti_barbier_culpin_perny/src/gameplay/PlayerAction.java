package gameplay;

public enum PlayerAction
{
	STOP,
	MOVERIGHT,
	MOVEUP,
	MOVELEFT,
	MOVEDOWN
}