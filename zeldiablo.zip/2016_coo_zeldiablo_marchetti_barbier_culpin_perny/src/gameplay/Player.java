package gameplay;

import app.Game;
import my_exception.NullGameException;

/**
 * @author marchett9u aka EnderAsh
 * 
 * Cette classe g�re le Joueur, qui est contr�l� par l'utilisateur
 */
public class Player extends Character
{
	PlayerAction action;
	
	private boolean alive;
	private boolean pickaxe;
	
	/**
	 * Player
	 * Constructeur qui appelle le constructeur parent
	 * 
	 * @param px
	 * coordonn�e x
	 * 
	 * @param py
	 * coordonn�e y
	 * 
	 * @param psm
	 * vitesse maximale
	 * @throws NullGameException 
	 */
	public Player(int px, int py, int psm, Game g) throws NullGameException
	{
		super(px, py, psm, g);
		action = PlayerAction.STOP;
		
		alive = true;
		pickaxe = false;
	}
	
	/**
	 * executeAction
	 * Cette m�thode effectue les changements en fonction de l'action d�sir�e (ex: d�placement)
	 * 
	 * @param action
	 * action � mettre � jour
	 */
	public void executeAction(PlayerAction act) {action = act;}
	public PlayerAction getAction() {return action;}

	public void manage()
	{
		if (action == PlayerAction.STOP)
		{
			if (speed > 0) speed--;
		}
		else if (action == PlayerAction.MOVERIGHT)
		{
			direction = Dir.EAST.toInt();
			if (speed < speedMax) speed++;
		}
		else if (action == PlayerAction.MOVEUP)
		{
			direction = Dir.NORTH.toInt();
			if (speed < speedMax) speed++;
		}
		else if (action == PlayerAction.MOVELEFT)
		{
			direction = Dir.WEST.toInt();
			if (speed < speedMax) speed++;
		}
		else if (action == PlayerAction.MOVEDOWN)
		{
			direction = Dir.SOUTH.toInt();
			if (speed < speedMax) speed++;
		}
		
		update();
	}
	
	public void die()
	{
		alive = false;
		System.out.println("aba mer2 t mor lol");
	}
	
	public boolean getAlive() {return alive;}
	public boolean hasPickaxe() {return pickaxe;}
	public void givePickaxe() {pickaxe = true;}
	public void takeBackPickaxe() {pickaxe = false;}
}