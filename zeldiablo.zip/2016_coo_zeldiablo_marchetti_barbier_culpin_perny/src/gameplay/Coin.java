package gameplay;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import app.Game;

public class Coin extends Item
{
	public static final int SCORE_ADD = 10;
	private BufferedImage img;
	
	/**
	 * Creation de l'objet Coin
	 * @param px
	 * @param py
	 * @param g
	 */
	public Coin(int px, int py, Game g)
	{
		super(px, py, g);
		
		try
		{
			img = ImageIO.read(new File("sprites/coin.png"));
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * Affiche l'objet
	 */
	@Override
	public void display(Graphics g)
	{
		g.drawImage(img, x, y, null);
	}

	/**
	 * Augmente le score
	 */
	@Override
	public void effect()
	{
		game.addScore(SCORE_ADD);
	}
}