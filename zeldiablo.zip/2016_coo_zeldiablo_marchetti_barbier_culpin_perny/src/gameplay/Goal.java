package gameplay;

import java.awt.Graphics;

public abstract class Goal {

	protected int x, y;
	public final static int SIZE = 32;
	
	public Goal(int a, int b)
	{
		if (a<0)
			a=0;
		if (b<0)
			b=0;
		this.x=a;
		this.y=b;
	}

	public int getX()
	{
		return this.x;
	}
	
	public int getY()
	{
		return this.y;
	}

	public boolean find(int a, int b)
	{
		return (a+Character.SIZE>=this.x && a<=this.x+Tresor.SIZE && b+Character.SIZE>=this.y && b<=this.y+Tresor.SIZE);
	}
	
	public abstract void display(Graphics g);
	
	
	
}
