package gameplay;

import java.awt.Graphics;

import app.Game;
import my_exception.NullGameException;

public abstract class Item
{
	public static final int SIZE = 32;
	
	protected int x, y;
	protected Game game;
	
	public Item(int px, int py, Game g)
	{
		x = (px >= 0 ? px : 0);
		y = (py >= 0 ? py : 0);
		if (g!=null)
			game = g;
		else 
			throw new NullGameException("impossible d'ajouter l'item, le jeu est null ou innexistant");
	}
	
	public boolean find(int fx, int fy)
	{
		return (fx < x + SIZE && fx + Character.SIZE > x && fy < y + SIZE && fy + Character.SIZE > y);
	}
	
	public int getX() {return x;}
	public int getY() {return y;}
	
	public abstract void display(Graphics g);
	public abstract void effect();
}