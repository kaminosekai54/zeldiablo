package gameplay;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import app.Game;

public class Apple extends Item
{
	private BufferedImage img;
	
	/**
	 * Creation de l'objet Apple
	 * @param px
	 * @param py
	 * @param g
	 */
	public Apple(int px, int py, Game g)
	{
		super(px, py, g);
		
		try
		{
			img = ImageIO.read(new File("sprites/apple.png"));
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * Affiche l'objet
	 */
	@Override
	public void display(Graphics g)
	{
		g.drawImage(img, x, y, null);
	}

	/**
	 * Fait fuir les ennemis
	 */
	@Override
	public void effect()
	{
		for (Character i : game.getCharacters())
		{
			((Enemy)i).panic();
		}
	}
}