package test;

import static org.junit.Assert.*;

import gameplay.Character;
import gameplay.Coin;
import gameplay.Player;
import gameplay.PlayerAction;
import gameplay.Tresor;

import java.awt.Point;

import map.Map;
import map.RandomFloor;
import my_exception.NullGameException;

import org.junit.Before;
import org.junit.Test;

import app.Game;

public class TestCoin 
{

	Game game;
	RandomFloor rf;
	Map m;
	Point pos;
	
	@Before
	public void initialiser()
	{
		game = new Game();
		rf = new RandomFloor(40,22,3,5,4,6);
		rf.generate(50);
		m = new Map();
		m.loadMap(rf);
		game.setMap(m);
		pos = rf.getRoom();
	}
	
	@Test
	public void testCoordonneeAZero() throws NullGameException
	{
		Coin c = new Coin(0,0,game);
		game.addItem(c);
		assertEquals("x devrait etre a 0",0,c.getX());
		assertEquals("y devrait etre a 0",0,c.getY());
	}
	
	@Test
	public void testCoordonnePositive() throws NullGameException
	{
		Coin c = new Coin(10,10,game);
		game.addItem(c);
		assertEquals("x devrait etre a 10",10,c.getX());
		assertEquals("y devrait etre a 10",10,c.getY());
	}
	
	@Test
	public void testCoordonneNegative() throws NullGameException
	{
		Coin c = new Coin(-10,-10,game);
		game.addItem(c);
		assertEquals("x devrait etre a 0",0,c.getX());
		assertEquals("y devrait etre a 0",0,c.getY());
	}
	
	@Test
	public void testScore() throws NullGameException, InterruptedException
	{
		while(!game.getMap().emptyPlaceWall(pos.x+50, pos.y)){
			rf = new RandomFloor(40, 22, 3, 5, 4, 6);
			rf.generate(50);
			
			m = new Map();
			m.loadMap(rf);
			game.setMap(m);
			
			pos = rf.getRoom();
		}
		Player p = new Player(pos.x,pos.y,5,game);
		Coin c = new Coin(pos.x+50, pos.y,game);
		Tresor t = new Tresor(0,0);
		game.addPlayer(p);
		game.addItem(c);
		game.addGoal(t);
		p.executeAction(PlayerAction.MOVERIGHT);
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		assertEquals("Le score doit etre de 10",10,game.getScore());
	}
	
	@Test
	public void testPositionOk() throws NullGameException
	{
		Coin c = new Coin(pos.x, pos.y, game);
		game.addItem(c);
		for (int i=0; i< game.getMap().getWalls().size(); i++){
			assertEquals("Coin ne devrait pas apparaitre dans un mur", game.getMap().emptyPlaceWall(c.getX(), c.getY()), true);
		}
		
	}
	
	@Test
	public void testCollisionPlayer() throws NullGameException, InterruptedException
	{
		while(!game.getMap().emptyPlaceWall(pos.x+50, pos.y)){
			rf = new RandomFloor(40, 22, 3, 5, 4, 6);
			rf.generate(50);
			
			m = new Map();
			m.loadMap(rf);
			game.setMap(m);
			
			pos = rf.getRoom();
		}
		Player p = new Player(pos.x, pos.y, 4, game);
		Coin c = new Coin(pos.x+50, pos.y, game);
		Tresor t = new Tresor(0,0);
		game.addPlayer(p);
		game.addGoal(t);
		game.addItem(c);
		p.executeAction(PlayerAction.MOVERIGHT);
		p.manage();
		game.update();
		assertEquals("player et coin doivent etre en collision", true, (p.getX() < c.getX() + Character.SIZE && p.getX() + Character.SIZE > t.getX() && p.getY() < c.getY() + Character.SIZE && p.getY() + Character.SIZE > c.getY())); 
	}

}
