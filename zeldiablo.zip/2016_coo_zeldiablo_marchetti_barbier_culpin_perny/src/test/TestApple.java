package test;

import static org.junit.Assert.assertEquals;

import java.awt.Point;

import org.junit.Before;
import org.junit.Test;

import app.Game;
import gameplay.Character;
import gameplay.Enemy;
import gameplay.Apple;
import gameplay.Player;
import gameplay.PlayerAction;
import gameplay.Tresor;
import map.Map;
import map.RandomFloor;
import my_exception.NullGameException;

public class TestApple {

	Game game;
	RandomFloor rf;
	Map m;
	Point pos;
	
	@Before
	public void initialiser()
	{
		game = new Game();
		rf = new RandomFloor(40,22,3,5,4,6);
		rf.generate(50);
		m = new Map();
		m.loadMap(rf);
		game.setMap(m);
		pos = rf.getRoom();
	}
	
	@Test
	public void testCoordonneeAZero() throws NullGameException
	{
		Apple a = new Apple(0,0,game);
		game.addItem(a);
		assertEquals("x devrait etre a 0",0,a.getX());
		assertEquals("y devrait etre a 0",0,a.getY());
	}
	
	@Test
	public void testCoordonnePositive() throws NullGameException
	{
		Apple a = new Apple(10,10,game);
		game.addItem(a);
		assertEquals("x devrait etre a 10",10,a.getX());
		assertEquals("y devrait etre a 10",10,a.getY());
	}
	
	@Test
	public void testCoordonneNegative() throws NullGameException
	{
		Apple a = new Apple(-10,-10,game);
		game.addItem(a);
		assertEquals("x devrait etre a 0",0,a.getX());
		assertEquals("y devrait etre a 0",0,a.getY());
	}
	
	@Test
	public void testPositionOk() throws NullGameException
	{
		Apple a = new Apple(pos.x, pos.y, game);
		game.addItem(a);
		for (int i=0; i< game.getMap().getWalls().size(); i++){
			assertEquals("Apple ne devrait pas apparaitre dans un mur", game.getMap().emptyPlaceWall(a.getX(), a.getY()), true);
		}
	}
	
	@Test
	public void testCollisionPlayer() throws NullGameException, InterruptedException
	{
		while(!game.getMap().emptyPlaceWall(pos.x+50, pos.y)){
			rf = new RandomFloor(40, 22, 3, 5, 4, 6);
			rf.generate(50);
			
			m = new Map();
			m.loadMap(rf);
			game.setMap(m);
			
			pos = rf.getRoom();
		}
		Player p = new Player(pos.x, pos.y, 4, game);
		Apple a = new Apple(pos.x+50, pos.y, game);
		Tresor t = new Tresor(0,0);
		game.addPlayer(p);
		game.addGoal(t);
		game.addItem(a);
		p.executeAction(PlayerAction.MOVERIGHT);
		p.manage();
		game.update();
		assertEquals("player et Apple doivent etre en collision", true, (p.getX() < a.getX() + Character.SIZE && p.getX() + Character.SIZE > t.getX() && p.getY() < a.getY() + Character.SIZE && p.getY() + Character.SIZE > a.getY())); 
	}
	
	@Test
	public void testAttraperPomme()
	{
		while(!game.getMap().emptyPlaceWall(pos.x+50, pos.y)){
			rf = new RandomFloor(40, 22, 3, 5, 4, 6);
			rf.generate(50);
			
			m = new Map();
			m.loadMap(rf);
			game.setMap(m);
			
			pos = rf.getRoom();
		}
		Player p = new Player(pos.x, pos.y, 4, game);
		Apple a = new Apple(pos.x+50, pos.y, game);
		Tresor t = new Tresor(0,0);
		pos = rf.getRoom();
		Enemy e = new Enemy(pos.x, pos.y, 4, game);
		game.addPlayer(p);
		game.addCharacter(e);
		game.addGoal(t);
		game.addItem(a);
		p.executeAction(PlayerAction.MOVERIGHT);
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		assertEquals("apple devrait faire passer enemy en panic", true, e.getPanic());
	}
	
}
