package test;

import static org.junit.Assert.assertEquals;

import java.awt.Point;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import app.Game;
import gameplay.Coin;
import gameplay.Enemy;
import gameplay.Pickaxe;
import gameplay.Player;
import gameplay.PlayerAction;
import gameplay.Stairs;
import gameplay.Tresor;
import map.Map;
import map.RandomFloor;

public class TestGame {

	private Game game;
	RandomFloor rf;
	Map m;
	Point pos;
	
	@Before
	public void initialiser()
	{
		game = new Game();
		rf = new RandomFloor(40, 22, 3, 5, 4, 6);
		rf.generate(50);
		
		m = new Map();
		m.loadMap(rf);
		game.setMap(m);
		
		pos = rf.getRoom();	
	
	}
	
	/**
	 * test constructeur
	 */
	
	@Test
	public void test_Constructeur(){
		assertEquals("le score devrait etre de zero",0,game.getScore());
		assertEquals("le nombre de chambre devrait etre de zero",0,game.getNbroom());
	}
	
	/**
	 * test l'ajout d'ennemi
	 */
	@Test
	public void testAjoutCharacter()
	{
		Enemy e = new Enemy(10,10,4,game);
		game.addCharacter(e);
		assertEquals("Il devrait y avoir un ennemi",1,game.getCharacters().size());
	}
	
	/**
	 * test l'ajout d'ennemi null
	 */
	@Test
	public void testAjoutCharacterNull()
	{
		game.addCharacter(null);
		assertEquals("Il ne decrait pas y avoir de Character",0,game.getCharacters().size());
	}
	
	/**
	 * test l'ajout d'un player 
	 */
	@Test
	public void testAjoutPlayer()
	{
		Player p = new Player(10,10,4,game);
		game.addPlayer(p);
		assertEquals("Il devrait y avoir un joueur",p,game.getPlayer());
	}
	
	/**
	 * test l'ajout d'un player null
	 */
	@Test
	public void testAjoutPlayerNull()
	{
		game.addPlayer(null);
		assertEquals("Il ne devrait pas y avoir de joueur",null,game.getPlayer());
	}
	
	/**
	 * test l'ajout d'un item
	 */
	@Test
	public void testAjoutItem()
	{
		Pickaxe pi = new Pickaxe(10,10,game);
		game.addItem(pi);
		assertEquals("Il devrait y avoir un item",1,game.getItems().size());
	}

	/**
	 * test l'ajout d'un item null
	 */
	@Test
	public void testAjoutItemNull()
	{
		game.addItem(null);
		assertEquals("Il ne devrait pas y avoir d'item",0,game.getItems().size());
	}
	
	/**
	 * test l'ajout d'un score 
	 */
	@Test
	public void testAjoutScorePositif()
	{
		game.addScore(10);
		assertEquals("Le score doit etre de 10",10,game.getScore());
	}
	
	/**
	 * test l'ajout de scorre nul
	 */
	@Test
	public void testAjoutScoreAZero()
	{
		game.addScore(10);
		game.addScore(0);
		assertEquals("Le score doit etre de 10",10,game.getScore());
	}
	
	/**
	 * test l'ajout d'un score le faisant passer negatif
	 */
	@Test
	public void testAjoutScoreNegatif()
	{
		game.addScore(5);
		game.addScore(-10);
		assertEquals("Le score doit etre a 0",0,game.getScore());
	}
	
	/**
	 * test l'ajout d'un objectif
	 */
	@Test
	public void testAjoutGoal()
	{
		Tresor t = new Tresor(10,10);
		game.addGoal(t);
		assertEquals("Il doit y avoir un goal",t,game.getGoal());
	}
	
	/**
	 * test l'ajout d'un objectif null
	 */
	@Test
	public void testAjoutGoalNull()
	{
		game.addGoal(null);
		assertEquals("Ill ne doit pas y avoir de goal",null,game.getGoal());
	}
	
	/**
	 * test l'ajout de map
	 */
	@Test
	public void test_AjoutMap(){
		Map m=new Map();
		game.setMap(m);
		assertEquals("mauvaise map",m,game.getMap());
		
	}
	
	/**
	 * test l'ajout d'une map null
	 */
	@Test
	public void test_AjoutMapNull(){
		Map m=new Map();
		game.setMap(m);
		game.setMap(null);
		assertEquals("la map  n'aurait pas du changer",m,game.getMap());
	}
	
	/**
	 * test le changement de sal
	 */
	@Test
	public void test_IncrementationNbroom(){

		while(!game.getMap().emptyPlaceWall(pos.x+50, pos.y)){
			rf = new RandomFloor(40, 22, 3, 5, 4, 6);
			rf.generate(50);
			
			m = new Map();
			m.loadMap(rf);
			game.setMap(m);
			
			pos = rf.getRoom();
		}
		Player p = new Player(pos.x, pos.y, 4, game);
		Stairs t = new Stairs(pos.x+50, pos.y);
		game.addPlayer(p);
		game.addGoal(t);
		p.executeAction(PlayerAction.MOVERIGHT);
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		assertEquals("mauvais nombre de chambre",1,game.getNbroom());
		}
	
	
	/**
	 * test si la map s'update bien
	 */

public void test_UpdateMap(){
	RandomFloor rf = new RandomFloor(40, 22, 3, 5, 4, 6);
	rf.generate(50);
	
	Map m = new Map();
	m.loadMap(rf);
	game.setMap(m);
	
	Point pos = rf.getRoom();
	Stairs st=new Stairs(pos.x,pos.y);
	pos = rf.getRoom();
	Player p=new Player(pos.x,pos.y,5,game);
	game.addPlayer(p);
	p.setCoords(st.getX(), st.getY());
	game.update();
	assertEquals("la map aurait du changer" ,false,game.getMap().equals(m));
}
}
