package test;

import static org.junit.Assert.*;
import map.Wall;
import org.junit.Test;

public class TestWall {

	@Test
	public void testCoordonneeAZero() 
	{
		Wall w = new Wall(0,0);
		assertEquals("x devrait etre a 0",0,w.getX());
		assertEquals("y devrait etre a 0",0,w.getY());
	}
	
	@Test
	public void testCoordonneePositive()
	{
		Wall w = new Wall(10,10);
		assertEquals("x devrait etre a 10",10,w.getX());
		assertEquals("y devrait etre a 10",10,w.getY());
	}
	
	@Test
	public void testCoordonneeNegative()
	{
		Wall w = new Wall(-10,-10);
		assertEquals("x devrait etre a 0",0,w.getX());
		assertEquals("y devrait etre a 0",0,w.getY());
	}

}
