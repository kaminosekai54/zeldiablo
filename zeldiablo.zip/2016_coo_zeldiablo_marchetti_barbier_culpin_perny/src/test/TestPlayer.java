package test;
import static org.junit.Assert.assertEquals;

import java.awt.Point;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import app.Game;
import gameplay.Enemy;
import gameplay.Player;
import gameplay.PlayerAction;
import gameplay.Tresor;
import map.Map;
import map.RandomFloor;
import my_exception.NullGameException;

public class TestPlayer 
{

	Game game;
	RandomFloor rf;
	Map m;
	Point pos;
	
	@Before
	public void initialiser(){
		game = new Game();
		
		rf = new RandomFloor(40, 22, 3, 5, 4, 6);
		rf.generate(50);
		
		m = new Map();
		m.loadMap(rf);
		game.setMap(m);
		
		pos = rf.getRoom();
	}
	@After
	/**
	 * Test du constructeur de Player  avec les valeurs n�gatives
	 */
	@Test
	public void testCoordonneeAZero() throws NullGameException 
	{
		
		Player c = new Player(0,0,0,game);
		assertEquals("x devrait etre a 0",0,c.getX());
		assertEquals("y devrait etre a 0",0,c.getY());
		assertEquals("sm devrait etre a 0",0,c.getSpeed());
	}
	
	/**
	 * Test du constructeur de Player avec les coordonnees positives
	 * @throws NullGameException 
	 */
	@Test
	public void testCoordonneePositive() throws NullGameException
	{
		
		Player c = new Player(10,20,4,game);
		assertEquals("x devrait etre a 10",10,c.getX());
		assertEquals("y devrait etre a 20",20,c.getY());
	}
	
	/**
	 * Test du constructeur de Player avec les coordonnees negatives
	 * @throws NullGameException 
	 */
	@Test
	public void testCoordonneeNegative() throws NullGameException
	{
		
		Player c = new Player(-10,-20,4,game);
		assertEquals("x devrait etre a 0",0,c.getX());
		assertEquals("y devrait etre a 0",0,c.getY());
	}
	
	/**
	 * test vitesse normal
	 * @throws NullGameException 
	 */
	
	@Test
	public void Test_normalSpeed() throws NullGameException{
		Player p=new Player(pos.x,pos.y,4,game);
		assertEquals("la vitesse devrait etre de ", 0, p.getSpeed());
		assertEquals("la vitesse max devrait etre de 4",4,p.getSpeedMax());
		
	}
	
	/**
	 *test si la vitesse max est n�gative
	 * @throws NullGameException 
	 */
	@Test
	public void test_negativeSpeed() throws NullGameException{
		Player p=new Player(pos.x,pos.y,-5,game);
		assertEquals("la vitesse max devrait etre de 1",1,p.getSpeedMax());
	
	}
	
	/**
	 * test la speed max initialiser a 0
	 * @throws NullGameException 
	 */

	@Test
	public void test_nullSpeed() throws NullGameException{
		Player p=new Player(pos.x,pos.y,0,game);
		assertEquals("la vitesse max devrait etre de 1",1,p.getSpeedMax());
	}
	
	
	/**
	 * Test du deplacement du Player vers la droite
	 * @throws NullGameException 
	 */
	@Test 
	public void testDeplacementDroite() throws NullGameException
	{
		Player p = new Player(pos.x, pos.y, 4, game);
		game.addPlayer(p);
		int lastX = p.getX();
		int lastY = p.getY();
		p.executeAction(PlayerAction.MOVERIGHT);
		p.manage();
		assertEquals("x devrait etre a +1",lastX+1,p.getX()); 
		assertEquals("y ne devrait pas avoir chang�",lastY,p.getY());
	}
	
	/**
	 * Test du deplacement du Player vers le bas
	 * @throws NullGameException 
	 */
	@Test 
	public void testDeplacementBas() throws NullGameException
	{
		Player p = new Player(pos.x, pos.y, 4, game);
		game.addPlayer(p);
		int lastX = p.getX();
		int lastY = p.getY();
		p.executeAction(PlayerAction.MOVEDOWN);
		p.manage();
		
		if (m.emptyPlaceWall(lastX+1,lastY)){
		assertEquals("x ne devrait pas avoir chang�",lastX,p.getX()); 
		assertEquals("y devrait �tre � +1",lastY+1,p.getY());
		}
		else{
			assertEquals("le player n'aurais pas du bouger en x",lastX,p.getX());
			assertEquals("le player n'aurais pas du bouger en y",lastY,p.getY());
		}
	}
	
	/**
	 * Test du deplacement du Player vers la gauche
	 * @throws NullGameException 
	 */
	@Test 
	public void testDeplacementGauche() throws NullGameException
	{
		Player p = new Player(pos.x, pos.y, 4, game);
		game.addPlayer(p);
		int lastX = p.getX();
		int lastY = p.getY();
		p.executeAction(PlayerAction.MOVELEFT);
		p.manage();
		if (m.emptyPlaceWall(lastX-1,lastY)){
			assertEquals("x devrait �tre � -1",lastX-1,p.getX());
			assertEquals("y ne devrait pas avoir chang�",lastY,p.getY());
		}
		else{
			assertEquals("le player n'aurais pas du bouger en x",lastX,p.getX());
			assertEquals("le player n'aurais pas du bouger en y",lastY,p.getY());
		}
	}
	
	/**
	 * Test du deplacement du Player vers le haut
	 * @throws NullGameException 
	 */
	@Test 
	public void testDeplacementHaut() throws NullGameException
	{
		Player p = new Player(pos.x, pos.y, 4, game);
		game.addPlayer(p);
		int lastX = p.getX();
		int lastY = p.getY();
		p.executeAction(PlayerAction.MOVEUP);
		p.manage();
		
		if (m.emptyPlaceWall(lastX,lastY-1)){
		assertEquals("x ne devrait pas avoir chang�",lastX,p.getX()); 
		assertEquals("y devrait �tre � -1",lastY-1,p.getY());}

		else{
			assertEquals("le player n'aurais pas du bouger en x",lastX,p.getX());
			assertEquals("le player n'aurais pas du bouger en y",lastY,p.getY());
		}}
	
	/**
	 * test si le jeu passer en parametre est null
	 * @throws NullGameException 
	 */
	@Test(expected=NullGameException.class)
	public void test_nullGame() throws NullGameException
	{
		new Player(pos.x,pos.y,5,null);
	}
	
	@Test
	public void testMortPlayer() throws NullGameException, InterruptedException
	{
		while(!game.getMap().emptyPlaceWall(pos.x+50, pos.y)){
			rf = new RandomFloor(40, 22, 3, 5, 4, 6);
			rf.generate(50);
			
			m = new Map();
			m.loadMap(rf);
			game.setMap(m);
			
			pos = rf.getRoom();
		}
		Player p = new Player(pos.x, pos.y, 4, game);
		Enemy e = new Enemy(pos.x+50, pos.y, 4, game);
		Tresor t = new Tresor(0,0);
		game.addPlayer(p);
		game.addCharacter(e);
		game.addGoal(t);
		game.update();
		game.update();
		game.update();
		game.update();
		game.update();
		game.update();
		game.update();
		game.update();
		game.update();
		assertEquals("player et enemy doivent etre en collision", false, p.getAlive());
	}
	
	@Test
	public void testPositionOk() throws NullGameException
	{
		Player p = new Player(pos.x, pos.y, 5, game);
		game.addPlayer(p);
		for (int i=0; i< game.getMap().getWalls().size(); i++){
			assertEquals("player ne devrait pas apparaitre dans un mur", game.getMap().emptyPlaceWall(p.getX(), p.getY()), true);
		}
		
	}
	
	
	
	
}
	

