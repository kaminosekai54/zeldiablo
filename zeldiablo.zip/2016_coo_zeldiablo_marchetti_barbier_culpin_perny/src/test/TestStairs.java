package test;

import static org.junit.Assert.assertEquals;

import java.awt.Point;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import app.Game;
import gameplay.Character;
import gameplay.Player;
import gameplay.PlayerAction;
import gameplay.Stairs;
import map.Map;
import map.RandomFloor;
import my_exception.NullGameException;

public class TestStairs {
	Game game;
	RandomFloor rf;
	Map m;
	Point pos;
	
	@Before
	public void initialiser(){
		game = new Game();
		
		rf = new RandomFloor(40, 22, 3, 5, 4, 6);
		rf.generate(50);
		
		m = new Map();
		m.loadMap(rf);
		game.setMap(m);
		
		pos = rf.getRoom();
		
	}
	@After
	
	@Test
	public void testCoordonneeAZero() throws NullGameException 
	{
		
		Stairs t = new Stairs(0,0);
		assertEquals("x devrait etre a 0",0,t.getX());
		assertEquals("y devrait etre a 0",0,t.getY());
	}
	
	@Test
	public void testCoordonneePositive() throws NullGameException 
	{
		
		Stairs t = new Stairs(10,10);
		assertEquals("x devrait etre a 10",10,t.getX());
		assertEquals("y devrait etre a 10",10,t.getY());
	}
	
	@Test
	public void testCoordonneeNegative() throws NullGameException 
	{
		
		Stairs t = new Stairs(-10,-10);
		assertEquals("x devrait etre a 0",0,t.getX());
		assertEquals("y devrait etre a 0",0,t.getY());
	}
	
	@Test
	public void testPositionOk() throws NullGameException
	{
		Stairs t = new Stairs(pos.x, pos.y);
		game.addGoal(t);
		for (int i=0; i< game.getMap().getWalls().size(); i++){
			assertEquals("Goal ne devrait pas apparaitre dans un mur", game.getMap().emptyPlaceWall(t.getX(), t.getY()), true);
		}
		
	}
	
	@Test
	public void testCollisionPlayer() throws NullGameException, InterruptedException
	{
		while(!game.getMap().emptyPlaceWall(pos.x+50, pos.y)){
			rf = new RandomFloor(40, 22, 3, 5, 4, 6);
			rf.generate(50);
			
			m = new Map();
			m.loadMap(rf);
			game.setMap(m);
			
			pos = rf.getRoom();
		}
		Player p = new Player(pos.x, pos.y, 4, game);
		Stairs t = new Stairs(pos.x+50, pos.y);
		game.addPlayer(p);
		game.addGoal(t);
		p.executeAction(PlayerAction.MOVERIGHT);
		p.manage();
		game.update();
		assertEquals("player et stairs doivent etre en collision", (p.getX() < t.getX() + Character.SIZE && p.getX() + Character.SIZE > t.getX() && p.getY() < t.getY() + Character.SIZE && p.getY() + Character.SIZE > t.getY()), !p.getAlive()); 
	}
	
	
}
