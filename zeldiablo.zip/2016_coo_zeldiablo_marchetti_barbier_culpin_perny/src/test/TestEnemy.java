package test;

import static org.junit.Assert.*;

import java.awt.Point;

import org.junit.Before;

import gameplay.Apple;
import gameplay.Character;
import gameplay.Enemy;
import gameplay.EnemyState;
import gameplay.Player;
import gameplay.PlayerAction;
import gameplay.Tresor;
import map.Map;
import map.RandomFloor;
import my_exception.NullGameException;

import org.junit.Test;

import app.Game;

public class TestEnemy {

	Game game;
	RandomFloor rf;
	Map m;
	Point pos;
	Tresor t;
	
	@Before
	public void initialiser(){
		game = new Game();
		
		rf = new RandomFloor(40, 22, 3, 5, 4, 6);
		rf.generate(50);
		
		m = new Map();
		m.loadMap(rf);
		game.setMap(m);
		
		pos = rf.getRoom();
		
		t = new Tresor(0,0);
		game.addGoal(t);
		
	}
	
	@Test
	public void testCoordonneeAZero() throws NullGameException 
	{
		Enemy e = new Enemy(0,0,4,game);
		game.addCharacter(e);
		assertEquals("x devrait etre a 0",0,e.getX());
		assertEquals("y devrait etre a 0",0,e.getY());
	}
	
	@Test
	public void testCoordonneePositive() throws NullGameException
	{
		Enemy e = new Enemy(10,10,4,game);
		game.addCharacter(e);
		assertEquals("x devrait etre a 10",10,e.getX());
		assertEquals("y devrait etre a 10",10,e.getY());
	}
	
	@Test
	public void testCoordonneeNegative() throws NullGameException
	{
		Enemy e = new Enemy(-10,-10,4,game);
		game.addCharacter(e);
		assertEquals("x devrait etre a 0",0,e.getX());
		assertEquals("y devrait etre a 0",0,e.getY());
	}	
	
	@Test
	public void testAggroRangePlayerOut() throws InterruptedException, NullGameException
	{
		Player p = new Player(pos.x+130, pos.y, 5, game);
		Enemy e = new Enemy(pos.x, pos.y, 5, game);
		Tresor t = new Tresor(0,0);
		game.addPlayer(p);
		game.addCharacter(e);
		game.addGoal(t);
		game.update();
		assertEquals("x ne devrait pas avoir chang�", pos.x, e.getX());
		assertEquals("y ne devrait pas avoir chang�", pos.y, e.getY());
	}
	
	@Test
	public void testAggroRangePlayerIn() throws InterruptedException, NullGameException
	{
		Player p = new Player(pos.x+64, pos.y, 5, game);
		Enemy e = new Enemy(pos.x, pos.y, 5, game);
		game.addPlayer(p);
		game.addCharacter(e);
		game.update();
		assertEquals("enemy devrait s'�tre rapproch� du player", true, ((p.getY() - e.getY())*(p.getY() - e.getY()) + (p.getX() - e.getX())*(p.getX() - e.getX())<((pos.x+64 - pos.x)*(pos.x+64 - pos.x))));
	}
	
	@Test
	public void testStateIni() throws NullGameException
	{
		Enemy e = new Enemy(pos.x, pos.y, 5, game);
		game.addCharacter(e);
		assertEquals("state devrait etre repos", EnemyState.STOP, e.getState());
	}
	
	@Test
	public void testStatePlayerInRange() throws InterruptedException, NullGameException
	{
		Enemy e = new Enemy(pos.x, pos.y, 5, game);
		Player p = new Player(pos.x, pos.y, 5, game);
		game.addCharacter(e);
		game.addPlayer(p);
		game.update();
		assertEquals("state devrait etre en chasse", EnemyState.CHASE, e.getState());
	}
	
	@Test
	public void testStatePlayerGone() throws InterruptedException, NullGameException
	{
		Enemy e = new Enemy(pos.x, pos.y, 5, game);
		Player p = new Player(pos.x, pos.y, 5, game);
		game.addCharacter(e);
		game.addPlayer(p);
		game.update();
		p = new Player(pos.x+300, pos.y+300, 5, game);
		game.addPlayer(p);
		game.update();
		assertEquals("state devrait etre repos", EnemyState.STOP, e.getState());
	}
	
	@Test(expected=NullPointerException.class)
	public void testPositionNull() throws NullGameException, NullPointerException{
			pos = null;
			new Enemy(pos.x, pos.y, 5, game);
	}
	
	@Test
	public void testSpeedUnderZero() throws NullGameException
	{
		Enemy e = new Enemy(pos.x, pos.y, -2, game);
		assertEquals("vitesse devrait etre a un", 1, e.getSpeedMax());
	}
	
	@Test
	public void testSpeedOverZero() throws NullGameException
	{
		Enemy e = new Enemy(pos.x, pos.y, 5, game);
		assertEquals("vitesse devrait etre a cinq", 5, e.getSpeedMax());
	}
	
	@Test(expected=NullGameException.class)
	public void testGameNull() throws NullGameException
	{
		new Enemy(pos.x,pos.y,5,null);
	}
	
	@Test
	public void testPositionOk() throws NullGameException
	{
		Enemy e = new Enemy(pos.x, pos.y, 5, game);
		game.addCharacter(e);
		for (int i=0; i< game.getMap().getWalls().size(); i++){
			assertEquals("enemy ne devrait pas apparaitre dans un mur", game.getMap().emptyPlaceWall(e.getX(), e.getY()), true);
		}
		
	}
	
	@Test
	public void testCollisionPlayer() throws NullGameException, InterruptedException
	{
		while(!game.getMap().emptyPlaceWall(pos.x+50, pos.y)){
			rf = new RandomFloor(40, 22, 3, 5, 4, 6);
			rf.generate(50);
			
			m = new Map();
			m.loadMap(rf);
			game.setMap(m);
			
			pos = rf.getRoom();
		}
		Player p = new Player(pos.x, pos.y, 4, game);
		Enemy e = new Enemy(pos.x+50, pos.y, 4, game);
		game.addPlayer(p);
		game.addCharacter(e);
		game.update();
		game.update();
		game.update();
		game.update();
		game.update();
		game.update();
		game.update();
		game.update();
		game.update();
		game.update();
		assertEquals("player et enemy doivent etre en collision", (p.getX() < e.getX() + Character.SIZE && p.getX() + Character.SIZE > e.getX() && p.getY() < e.getY() + Character.SIZE && p.getY() + Character.SIZE > e.getY()), !p.getAlive()); 
	}
	
	@Test
	public void testPanicInit(){
		Enemy e = new Enemy(pos.x+50, pos.y, 4, game);
		assertEquals("planic devrait etre a false", e.getPanic(), false);
	}
	
	@Test
	public void testPlayerTakeApple(){
		while(!game.getMap().emptyPlaceWall(pos.x+50, pos.y)){
			rf = new RandomFloor(40, 22, 3, 5, 4, 6);
			rf.generate(50);
			
			m = new Map();
			m.loadMap(rf);
			game.setMap(m);
			
			pos = rf.getRoom();
		}
		Player p = new Player(pos.x, pos.y, 4, game);
		Apple a = new Apple(pos.x+50, pos.y, game);
		Tresor t = new Tresor(0,0);
		pos = rf.getRoom();
		Enemy e = new Enemy(pos.x, pos.y, 4, game);
		game.addPlayer(p);
		game.addCharacter(e);
		game.addGoal(t);
		game.addItem(a);
		p.executeAction(PlayerAction.MOVERIGHT);
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		assertEquals("apple devrait faire passer enemy en panic", true, e.getPanic());
	}
	
	@Test
	public void testPanicRevientFalse(){
		while(!game.getMap().emptyPlaceWall(pos.x+50, pos.y)){
			rf = new RandomFloor(40, 22, 3, 5, 4, 6);
			rf.generate(50);
			
			m = new Map();
			m.loadMap(rf);
			game.setMap(m);
			
			pos = rf.getRoom();
		}
		Player p = new Player(pos.x, pos.y, 4, game);
		Apple a = new Apple(pos.x+50, pos.y, game);
		Tresor t = new Tresor(0,0);
		pos = rf.getRoom();
		Enemy e = new Enemy(pos.x, pos.y, 4, game);
		game.addPlayer(p);
		game.addCharacter(e);
		game.addGoal(t);
		game.addItem(a);
		p.executeAction(PlayerAction.MOVERIGHT);
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		for(int i=0; i<=200;i++){
			p.manage();
			game.update();
		}
		assertEquals("enemy devrait repasser a panic=false", false, e.getPanic());
	}
	

}
