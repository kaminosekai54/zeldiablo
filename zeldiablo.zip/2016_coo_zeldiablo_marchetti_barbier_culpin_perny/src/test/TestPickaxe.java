package test;

import static org.junit.Assert.assertEquals;

import java.awt.Point;

import org.junit.Before;
import org.junit.Test;

import app.Game;
import gameplay.Character;
import gameplay.Pickaxe;
import gameplay.Player;
import gameplay.PlayerAction;
import gameplay.Tresor;
import map.Map;
import map.RandomFloor;
import my_exception.NullGameException;

public class TestPickaxe {

	Game game;
	RandomFloor rf;
	Map m;
	Point pos;
	
	@Before
	public void initialiser()
	{
		game = new Game();
		rf = new RandomFloor(40,22,3,5,4,6);
		rf.generate(50);
		m = new Map();
		m.loadMap(rf);
		game.setMap(m);
		pos = rf.getRoom();
	}
	
	@Test
	public void testCoordonneeAZero() throws NullGameException
	{
		Pickaxe p = new Pickaxe(0,0,game);
		game.addItem(p);
		assertEquals("x devrait etre a 0",0,p.getX());
		assertEquals("y devrait etre a 0",0,p.getY());
	}
	
	@Test
	public void testCoordonnePositive() throws NullGameException
	{
		Pickaxe p = new Pickaxe(10,10,game);
		game.addItem(p);
		assertEquals("x devrait etre a 10",10,p.getX());
		assertEquals("y devrait etre a 10",10,p.getY());
	}
	
	@Test
	public void testCoordonneNegative() throws NullGameException
	{
		Pickaxe p = new Pickaxe(-10,-10,game);
		game.addItem(p);
		assertEquals("x devrait etre a 0",0,p.getX());
		assertEquals("y devrait etre a 0",0,p.getY());
	}
	
	@Test
	public void testPositionOk() throws NullGameException
	{
		Pickaxe p = new Pickaxe(pos.x, pos.y, game);
		game.addItem(p);
		for (int i=0; i< game.getMap().getWalls().size(); i++){
			assertEquals("Pickaxe ne devrait pas apparaitre dans un mur", game.getMap().emptyPlaceWall(p.getX(), p.getY()), true);
		}
	}
	
	@Test
	public void testCollisionPlayer() throws NullGameException, InterruptedException
	{
		while(!game.getMap().emptyPlaceWall(pos.x+50, pos.y)){
			rf = new RandomFloor(40, 22, 3, 5, 4, 6);
			rf.generate(50);
			
			m = new Map();
			m.loadMap(rf);
			game.setMap(m);
			
			pos = rf.getRoom();
		}
		Player p = new Player(pos.x, pos.y, 4, game);
		Pickaxe c = new Pickaxe(pos.x+50, pos.y, game);
		Tresor t = new Tresor(0,0);
		game.addPlayer(p);
		game.addGoal(t);
		game.addItem(c);
		p.executeAction(PlayerAction.MOVERIGHT);
		p.manage();
		game.update();
		assertEquals("player et pickaxe doivent etre en collision", true, (p.getX() < c.getX() + Character.SIZE && p.getX() + Character.SIZE > t.getX() && p.getY() < c.getY() + Character.SIZE && p.getY() + Character.SIZE > c.getY())); 
	}
	
	@Test
	public void testDestructionMur()
	{
		while(game.getMap().emptyPlaceWall(pos.x+50, pos.y)){
			rf = new RandomFloor(40, 22, 3, 5, 4, 6);
			rf.generate(50);
			
			m = new Map();
			m.loadMap(rf);
			game.setMap(m);
			
			pos = rf.getRoom();
		}
		Player p = new Player(pos.x, pos.y, 4, game);
		Pickaxe c = new Pickaxe(pos.x, pos.y, game);
		Tresor t = new Tresor(0,0);
		game.addPlayer(p);
		game.addGoal(t);
		game.addItem(c);
		p.executeAction(PlayerAction.MOVERIGHT);
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		p.manage();
		game.update();
		assertEquals("player devrait detruire mur", true, game.getMap().emptyPlaceWall(pos.x+50, pos.y));
	}
	
}
