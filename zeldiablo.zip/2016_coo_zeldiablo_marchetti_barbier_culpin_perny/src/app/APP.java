package app;

import java.awt.Dimension;
import java.awt.Point;

import javax.swing.JFrame;

import gameplay.Apple;
import gameplay.Coin;
import gameplay.Enemy;
import gameplay.Pickaxe;
import gameplay.Player;
import gameplay.Stairs;
import gameplay.Tresor;
import graphique.GameWindow;
import map.Map;
import map.RandomFloor;
import my_exception.NullGameException;

public class APP {

	private static JFrame fenetre;
	private static Game game;
	
	public static final int NUMBER_OF_ENEMIES = 1;
	public static final int NUMBER_OF_COINS = 10;

	public static void main(String[] args) throws InterruptedException, NullGameException
	{
		fenetre = new JFrame("Zeldiablo");
		game = new Game();
		start();
	}
	
	/**
	 * methode static cette methode permet de relancer le jeux
	 * 
	 * @throws NullGameException
	 * @throws InterruptedException
	 */
	public static void start() throws InterruptedException, NullGameException
	{
		RandomFloor rf = new RandomFloor(40, 22, 3, 5, 4, 6);
		rf.generate(50);

		Map m = new Map();
		m.loadMap(rf);
		game.setMap(m);

		Point pos = rf.getRoom();
		Player p = new Player(pos.x, pos.y, 5, game);
		game.addPlayer(p);

		pos = rf.getRoom();
		Stairs st = new Stairs(pos.x, pos.y);
		game.addGoal(st);

		for (int i = 0; i < NUMBER_OF_ENEMIES; i++) {
			pos = rf.getRoom();
			Enemy e = new Enemy(pos.x, pos.y, 4, game);
			game.addCharacter(e);
		}

		for (int i = 0; i < NUMBER_OF_COINS; i++) {
			pos = rf.getRoom();
			Coin c = new Coin(pos.x, pos.y, game);
			game.addItem(c);
		}

		pos = rf.getRoom();
		Apple a = new Apple(pos.x, pos.y, game);
		game.addItem(a);

		pos = rf.getRoom();
		Pickaxe pi = new Pickaxe(pos.x, pos.y, game);
		game.addItem(pi);

		GameWindow gw = new GameWindow(game);
		fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		fenetre.setPreferredSize(new Dimension(1280, 720));
		fenetre.setContentPane(gw);
		fenetre.pack();
		fenetre.requestFocus();
		gw.requestFocusInWindow();
		fenetre.setVisible(true);

		while (fenetre.isActive()) {
			long timeStart = System.currentTimeMillis();

			game.update();
			gw.update();
			gw.repaint();

			long timefinal = System.currentTimeMillis() - timeStart;

			if (!(20 - timefinal < 0))
				Thread.sleep((long) (20 - timefinal));

			
			if (!game.getPlayer().getAlive())
			{
				gw.update();
				gw.repaint();
				game.end();
			}
			
			if (game.getGoal().find(game.getPlayer().getX(), game.getPlayer().getY()) && game.getGoal() instanceof Tresor)
			{
				gw.setWin(true);
				gw.update();
				gw.repaint();
				game.end();
			}
		}
	}
}