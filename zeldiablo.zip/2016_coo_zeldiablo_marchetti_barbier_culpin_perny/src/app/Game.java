package app;

import java.awt.Point;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import gameplay.Apple;
import gameplay.Character;
import gameplay.Coin;
import gameplay.Enemy;
import gameplay.Goal;
import gameplay.Item;
import gameplay.Pickaxe;
import gameplay.Player;
import gameplay.Stairs;
import gameplay.Tresor;
import map.Map;
import map.RandomFloor;
import my_exception.NullGameException;

public class Game
{
	private Player player;
	private ArrayList<Character> characters;
	private ArrayList<Item> items;
	private Map map;
	private Goal goal;
	private int score;
	private int nbroom;

	/**
	 * Constructeur qui cree un jeu
	 */
	public Game() {
		characters = new ArrayList<Character>(0);
		items = new ArrayList<Item>(0);
		
		nbroom = 0;
		score = 0;
	}

	/**
	 * Ajoute un personnage
	 * @param c
	 */
	public void addCharacter(Character c) {
		if (c!=null)
		characters.add(c);
	}
	
	/**
	 * Ajoute un objet
	 * @param i
	 */
	public void addItem(Item i)
	{
		if (i != null)
			items.add(i);
	}
	
	/**
	 * Supprime l'item sur la position i
	 * @param i
	 */
	public void removeItemByIndex(int i) {
		if(i<Item.SIZE)
		items.remove(i);
	}

	/**
	 * Retourne d'une map
	 * @return
	 */
	public Map getMap() {
		return map;
	}

	/**
	 * Modification d'un map
	 * @param m
	 */
	public void setMap(Map m) {
		if (m!=null)
		map = m;
	}

	/**
	 * Ajoute un objectif
	 * @param t
	 */
	public void addGoal(Goal t) {
		if (t != null)
			this.goal = t;
	}

	/**
	 * Retourne un objectif
	 * @return
	 */
	public Goal getGoal() {
		return this.goal;
	}
	
	/**
	 * Retourne une liste d'objet
	 * @return
	 */
	public ArrayList<Item> getItems() {return items;}

	/**
	 * Mise a jour de tous les attributs du jeu en fonction des actions du joueurs et ennemis
	 * @throws NullGameException
	 */
	public void update() throws NullGameException {

		player.manage();
		
		if (goal.find(this.player.getX(), this.player.getY()) && goal instanceof Stairs) {

			RandomFloor rf = new RandomFloor(40, 22, 3, 5, 4, 6);
			rf.generate(50);
			map.refreshMap(rf);
			Point pos = rf.getRoom();
			this.player.setCoords(pos.x, pos.y);
			player.takeBackPickaxe();
			pos = rf.getRoom();
			
			items.clear();
			characters.clear();
			
			for (int i = 0 ; i < APP.NUMBER_OF_ENEMIES * (nbroom + 1) ; i++)
			{
				pos = rf.getRoom();
				Enemy e = new Enemy(pos.x, pos.y, 4, this);
				addCharacter(e);
			}
			
			for (int i = 0 ; i < 10 ; i++)
			{
				pos = rf.getRoom();
				Coin c = new Coin(pos.x, pos.y, this);
				addItem(c);
			}
			
			pos = rf.getRoom();
			Apple a = new Apple(pos.x, pos.y, this);
			addItem(a);
			
			pos = rf.getRoom();
			Pickaxe pi = new Pickaxe(pos.x, pos.y, this);
			addItem(pi);
			
			if (nbroom < 10) {
				nbroom++;
				pos = rf.getRoom();
				this.goal = new Stairs(pos.x, pos.y);

			} else {
				pos = rf.getRoom();
				this.goal = new Tresor(pos.x, pos.y);;
			}
		}
		
		for (Item i : items)
		{
			if (i.find(player.getX(), player.getY()))
			{
				i.effect();
				items.remove(i);
				break;
			}
		}
		
		for (Character i : characters)
		{
			i.manage();

			if (player.getX() < i.getX() + Character.SIZE && player.getX() + Character.SIZE > i.getX() && player.getY() < i.getY() + Character.SIZE && player.getY() + Character.SIZE > i.getY())
				player.die();
		}
	}
	
	public int getNbroom(){return this.nbroom;}

	/**
	 * Ajoute un joueur
	 * @param p
	 */
	public void addPlayer(Player p) {
		if (p!=null)
		player = p;
	}

	/**
	 * Retourne un joueur
	 * @return
	 */
	public Player getPlayer() {
		return player;
	}

	/**
	 * Retourne une liste de personnage
	 * @return
	 */
	public ArrayList<Character> getCharacters() {
		return characters;
	}
	
	/**
	 * Ajoute un score
	 * @param v
	 */
	public void addScore(int v) {
		if (score+v>=0)
		score += v;
		else
			score=0;
	}
	
	/**
	 * Retourne le score
	 * @return
	 */
	public int getScore() {return score;}
	
	/**
	 * Met fin au jeu et propose au joueur de recommencer ou non
	 */
	public void end()
	{
		characters.clear();
		items.clear();
		player = null;
		score = 0;
		nbroom = 0;
		
		int option = JOptionPane.showConfirmDialog(null, "Recommencer ?", "Le jeu est termin�.",
				JOptionPane.YES_NO_OPTION, JOptionPane.NO_OPTION);

		if (option == JOptionPane.NO_OPTION)
			System.exit(0);
		if (option == JOptionPane.CLOSED_OPTION)
			System.exit(0);

		if (option == JOptionPane.YES_OPTION)
			try {
				APP.start();
			} catch (NullGameException | InterruptedException e) {
				e.printStackTrace();
			}
	}
}